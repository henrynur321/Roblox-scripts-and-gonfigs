--Homergay Private module by sussy guy/me--
chattags = {
		["undermultiplied"] = {
			NameColor = {r = 0, g = 255, b = 255},
			Tags = {
				{
					TagColor = {r = 255, g = 255, b = 0},
					TagText = "HomerWare Buyers"
				}
			}
		}
	}
repeat task.wait() until game:IsLoaded()
repeat task.wait() until shared.GuiLibrary
local GuiLibrary = shared.GuiLibrary
local ScriptSettings = {}
local UIS = game:GetService("UserInputService")
local COB = function(tab, argstable) 
    return GuiLibrary["ObjectsThatCanBeSaved"][tab.."Window"]["Api"].CreateOptionsButton(argstable)
end


function notify(text)
    local frame = GuiLibrary["CreateNotification"]("HomerGay Notification", text, 5, "assets/WarningNotification.png")
    frame.Frame.Frame.ImageColor3 = Color3.fromRGB(255, 64, 64)
end
function boxnotify(text)
    if messagebox then
        messagebox(text, "HomerGay Private", 0)
     end
end


--dayum lmao--


local AnticheatDisabler = COB("Blatant", {
    Name = "PingSpeed",
    Function = function(callback) 
        if callback then
        game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 41
        end
    end,
    Default = false,
    HoverText = "For Trash Ping"
})
local AntiCrash = COB("World", {
    Name = "AntiCrash",
    Function = function(callback) 
        if callback then
            ScriptSettings.AntiCrash = true
            while wait(1.5) do
                if not ScriptSettings.AntiCrash == true then return end
                if game:GetService("Workspace"):GetRealPhysicsFPS() < ScriptSettings.AntiCrash_MinFps then
                    game:Shutdown()
                    boxnotify("FPS Are under minimum. Closed game.")
                end  
                if math.floor(tonumber(game:GetService("Stats"):FindFirstChild("PerformanceStats").Ping:GetValue())) > ScriptSettings.AntiCrash_MaxPing then
                    game:Shutdown()
		    boxnotify("Ping Are over maximum. Closed game.")
                end
            end       
        else
            ScriptSettings.AntiCrash = false
        end
    end,
    Default = false,
    HoverText = "Automatically shutdowns game when fps or ping too low/high"
})
AntiCrash.CreateSlider({
    ["Name"] = "MinFps",
    ["Min"] = 0,
    ["Max"] = 100,
    ["Function"] = function(val)
        ScriptSettings.AntiCrash_MinFps = val
    end,
    ["HoverText"] = "Minimum fps before closing roblox",
    ["Default"] = 10
})
AntiCrash.CreateSlider({
    ["Name"] = "MaxPing",
    ["Min"] = 1000,
    ["Max"] = 100000,
    ["Function"] = function(val)
        ScriptSettings.AntiCrash_MaxPing = val
    end,
    ["HoverText"] = "Minimum fps before closing roblox",
    ["Default"] = 10
})

local AnticheatDisabler = COB("Blatant", {
    Name = "PingFlight.",
    Function = function(callback) 
        if callback then
          workspace.Gravity = 10
        else
            workspace.Gravity = 196.19999694824
        end
    end,
    Default = false,
    HoverText = "Small Distance Only"
})
slowautowin = GuiLibrary["ObjectsThatCanBeSaved"]["UtilityWindow"]["Api"].CreateOptionsButton({
		["Name"] = "SlowAutowin",
		["Function"] = function(callback)
			if callback then
				local character = game.Players.LocalPlayer.Character
				character.PrimaryPart.CFrame = character.PrimaryPart.CFrame * CFrame.new(0,999,0)
				character.PrimaryPart:Destroy()
				character.Head.Anchored = true
                          else
							createwarning("HomerGay", "Disabling SlowAutowin", 5)
							game.Players.LocalPlayer.Character.Head:Destroy()
							if game.Players.LocalPlayer.Character.Humanoid.Health < 5 then 
								local deathmanok = game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart").position
								wait(1.5)
								game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(deathmanok)
							end
			end
		end,
		["HoverText"] = "Wins if everyone leaves"
	})
runcode(function()
	local godmodeacdisabler = {["Enabled"] = false}

	godmodeacdisabler = GuiLibrary["ObjectsThatCanBeSaved"]["UtilityWindow"]["Api"].CreateOptionsButton({
		["Name"] = "GodmodeAnticheatDisabler",
		["Function"] = function(callback)
			if callback then
				wait(2)
				local plr = game.Players.LocalPlayer
                local chr = plr.Character
                local da = chr.HumanoidRootPart
                   while(true) do
                    da.Parent = nil
                       chr:MoveTo(chr:GetPivot().p)
                            wait()
                            da.Parent = chr
                             wait(0.25)
                   end
				createwarning("HomerGay", "Succesfully removed hrp", 5)

			else
				createwarning("Homergay", "Reset to disable", 5)

			end
		end,
		["HoverText"] = "Advanced hrp remover"
	})
end)
runcode(function()
	local hanggliderdisabler = {["Enabled"] = false}

	hanggliderdisabler = GuiLibrary["ObjectsThatCanBeSaved"]["UtilityWindow"]["Api"].CreateOptionsButton({
		["Name"] = "HangGliderDisabler",
		["Function"] = function(callback)
			if callback then
                        hanggliderdisabler["ToggleButton"](false)
			game.ReplicatedStorage.rbxts_include.node_modules.net.out._NetManaged.HangGliderUse:FireServer()
			wait(1)
			createwarning("HomerGay", "Disabled Anticheat", 5)
			wait(5)
			createwarning("HonerGay", "use 150 heatseeker", 10)
			wait(0.1)
			createwarning("HomerGay", "dont get hit and you can", 10)
			wait(0.1)
			createwarning("HomerGay", "You can know inf fly as long as you", 10)
			end
		end,
		["HoverText"] = "Must be holding a hang glider."
	})
	end)
	runcode(function()
	local dinoexploit = {["Enabled"] = false}

	dinoexploit = GuiLibrary["ObjectsThatCanBeSaved"]["BlatantWindow"]["Api"].CreateOptionsButton({
		["Name"] = "DinoExploit",
		["HoverText"] = "Gives you the dino ability. (found by qwakr and his friend)",
		["Function"] = function(callback)
			 if callback then
                          createwarning("HomerGay", "Cooldown...", 30)
                          dinoexploit["ToggleButton"](false)
                           GuiLibrary["ObjectsThatCanBeSaved"]["SpeedSpeedSlider"]["Api"]["SetValue"](140)
                           game:GetService("ReplicatedStorage")["events-@easy-games/game-core:shared/game-core-networking@getEvents.Events"].useAbility:FireServer("dino_charge")
                           wait(3)
                         GuiLibrary["ObjectsThatCanBeSaved"]["SpeedSpeedSlider"]["Api"]["SetValue"](81)
		 end
           end
      })
 end)
runcode(function()
	local chatdisabler = {["Enabled"] = false}

	chatdisabler = GuiLibrary["ObjectsThatCanBeSaved"]["UtilityWindow"]["Api"].CreateOptionsButton({
		["Name"] = "ChatDisabler",
		["HoverText"] = "Disables chat 90% of the time",
		["Function"] = function(callback)
			 if callback then
                          chatdisabler["ToggleButton"](false)
                            createwarning("HomerGay", "Chat delayed/disabled while running", 150)
                            local count = 60
                              repeat
                                  wait(2.5)
                                count = count - 1
                              game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(" ", "All")
                          until count == 0
		 end
            end
        })
 end)
	
local AnticheatDisabler = COB("World", {
    Name = "OldAntiVoid",
    Function = function(callback) 
        if callback then
            local antivoidpart = Instance.new("Part", Workspace)
            antivoidpart.Name = "AntiVoid"
            antivoidpart.Size = Vector3.new(2100, 0.5, 2000)
            antivoidpart.Position = Vector3.new(160.5, 25, 247.5)
            antivoidpart.Transparency = 0.4
            antivoidpart.Anchored = true
            antivoidpart.Touched:connect(function(dumbcocks)
                if dumbcocks.Parent:WaitForChild("Humanoid") and dumbcocks.Parent.Name == lplr.Name then
                    game.Players.LocalPlayer.Character.Humanoid:ChangeState("Jumping")
                    wait(0.2)
                    game.Players.LocalPlayer.Character.Humanoid:ChangeState("Jumping")
                    wait(0.2)
                    game.Players.LocalPlayer.Character.Humanoid:ChangeState("Jumping")
                end
            end)
        end
    end,
    Default = false,
    HoverText = "Old AntiVoid recreation"
})

local BoostAirJump = {["Enabled"] = false}
BoostAirJump = GuiLibrary["ObjectsThatCanBeSaved"]["BlatantWindow"]["Api"].CreateOptionsButton({
    ["Name"] = "BoostAirJump",
    ["Function"] = function(callback)
        if callback then
            task.spawn(function()
                repeat
                    task.wait(0.1)
                    if BoostAirJump["Enabled"] == false then break end
                    entity.character.HumanoidRootPart.Velocity = entity.character.HumanoidRootPart.Velocity + Vector3.new(0,40,0)
                until BoostAirJump["Enabled"] == false
            end)
        end
    end,
    ["HoverText"] = "HomerGay Private"
})

local AnticheatDisabler = COB("Utility", {
	["Name"] = "AnticheatDisabler",
	["Function"] = function(callback)
		if callback then
			pcall(function()
				ScriptSettings.AnticheatDisabler = true
                                        local function disablerFunction()
	     local lplr = game.Players.LocalPlayer
        lplr.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
        lplr.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Dead)
        repeat task.wait() until lplr.Character.Humanoid.MoveDirection ~= Vector3.zero
        task.wait(0.2)
        lplr.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
        lplr.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Running)
        workspace.Gravity = 192.6    
    end
             disablerFunction()
			end)
		else
			pcall(function()
				ScriptSettings.AnticheatDisabler = false
			end)
		end
	end,
	["Default"] = false,
	["HoverText"] = "yes its real stfu"
})
AnticheatDisabler.CreateSlider({
    ["Name"] = "Delay",
	["Double"] = 100,
    ["Min"] = 0,
    ["Max"] = 100,
    ["Function"] = function(val)
        ScriptSettings.AnticheatDisabler_Delay = val
    end,
    ["HoverText"] = "Delay",
    ["Default"] = 0.05
})


local InfJump = COB("Utility", {
	["Name"] = "InfJump",
	["Function"] = function(callback)
		if callback then
			pcall(function()
				ScriptSettings.InfJump = true
				game:GetService("UserInputService").JumpRequest:connect(function()
					if not ScriptSettings.InfJump == true then return end
					if not ScriptSettings.InfJump_Alr then
					    game:GetService("Players").LocalPlayer.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
					    ScriptSettings.InfJump_Alr = true
					    task.wait(0.125)
					    ScriptSettings.InfJump_Alr = false
					else
					    task.wait()
					end
				end)
			end)
		else
			pcall(function()
				ScriptSettings.InfJump = false
			end)
		end
	end,
	["Default"] = false,
	["HoverText"] = "Makes you can jump infinetly"
})